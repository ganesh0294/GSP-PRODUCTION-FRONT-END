import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-user-manager',
  templateUrl: './admin-user-manager.component.html',
  styleUrls: ['./admin-user-manager.component.scss']
})
export class AdminUserManagerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
